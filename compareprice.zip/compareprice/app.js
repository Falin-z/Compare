const url = "http://wxq.vip.qydev.com/api"
export default url;

